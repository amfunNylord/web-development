<!DOCTYPE html>
<html lang="ru">
  <head>
    <meta charset="UTF-8">
    <title>Don`t do it</title>
    <link rel="stylesheet" href="../web/css/style31.css" />
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@500;600;700&family=Roboto+Condensed&display=swap" rel="stylesheet">
  </head>
  <body>
    <form method="POST" action="printData.php">
<!--БЭM название первого дива и компоненты-->
      <div class="get-form">
        <input type="email" name="email" placeholder="Email" class="get-form__input-text" />
        <input type="submit" value="Получить данные" class="get-form__submit-button" />
      </div>
    </form>
  </body>
</html>
